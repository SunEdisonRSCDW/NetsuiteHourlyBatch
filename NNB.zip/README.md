# S3-to-Redshift-using-Lambda
Data transformation from AWS S3 to AWS Redshift using AWS Lambda scripting (JSON Parsing). 
